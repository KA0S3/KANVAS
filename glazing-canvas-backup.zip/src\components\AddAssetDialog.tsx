 import { useState } from "react";
 import {
   Dialog,
   DialogContent,
   DialogHeader,
   DialogTitle,
   DialogTrigger,
 } from "@/components/ui/dialog";
 import { Button } from "@/components/ui/button";
 import { Input } from "@/components/ui/input";
 import { Plus, FileText, Image, Film, Music, Code, File } from "lucide-react";
 import type { Asset } from "./AssetItem";
 
 interface AddAssetDialogProps {
  onAddAsset: (asset: Omit<Asset, "id" | "x" | "y">) => void;
 }
 
 const assetTypes: { type: Asset["type"]; icon: React.ElementType; label: string }[] = [
   { type: "image", icon: Image, label: "Image" },
   { type: "document", icon: FileText, label: "Document" },
   { type: "video", icon: Film, label: "Video" },
   { type: "audio", icon: Music, label: "Audio" },
   { type: "code", icon: Code, label: "Code" },
   { type: "other", icon: File, label: "Other" },
 ];
 
 export function AddAssetDialog({ onAddAsset }: AddAssetDialogProps) {
   const [open, setOpen] = useState(false);
   const [name, setName] = useState("");
   const [selectedType, setSelectedType] = useState<Asset["type"]>("document");
 
   const handleSubmit = (e: React.FormEvent) => {
     e.preventDefault();
     if (!name.trim()) return;
     onAddAsset({ name: name.trim(), type: selectedType });
     setName("");
     setSelectedType("document");
     setOpen(false);
   };
 
   return (
     <Dialog open={open} onOpenChange={setOpen}>
       <DialogTrigger asChild>
         <Button variant="cosmic" size="sm" className="gap-2">
           <Plus className="w-4 h-4" />
           Add Asset
         </Button>
       </DialogTrigger>
       <DialogContent className="glass-strong cosmic-glow border-glass-border/30">
         <DialogHeader>
           <DialogTitle className="text-foreground text-glow">Add New Asset</DialogTitle>
         </DialogHeader>
         <form onSubmit={handleSubmit} className="space-y-4">
           <div>
             <Input
               placeholder="Asset name..."
               value={name}
               onChange={(e) => setName(e.target.value)}
               className="bg-muted/50 border-glass-border/30 focus:border-primary/50"
             />
           </div>
           <div className="grid grid-cols-3 gap-2">
             {assetTypes.map(({ type, icon: Icon, label }) => (
               <button
                 key={type}
                 type="button"
                 onClick={() => setSelectedType(type)}
                 className={`p-3 rounded-lg flex flex-col items-center gap-1 transition-all ${
                   selectedType === type
                     ? "glass cosmic-glow-subtle border-primary/40"
                     : "glass hover:border-primary/20"
                 }`}
               >
                 <Icon className={`w-5 h-5 ${selectedType === type ? "text-primary" : "text-muted-foreground"}`} />
                 <span className={`text-xs ${selectedType === type ? "text-primary" : "text-muted-foreground"}`}>
                   {label}
                 </span>
               </button>
             ))}
           </div>
           <Button type="submit" variant="cosmic" className="w-full">
             Add Asset
           </Button>
         </form>
       </DialogContent>
     </Dialog>
   );
 }