 import { useState, useCallback, useRef, useEffect } from "react";
import { Sparkles, ArrowLeft } from "lucide-react";
import { AssetItem, type Asset } from "./AssetItem";
import { AddAssetDialog } from "./AddAssetDialog";
import { useAssetTree } from "@/hooks/useAssetTree";
import { useAssetStore } from "@/stores/assetStore";
import { 
  globalToLocalCoords, 
  localToGlobalCoords, 
  screenToViewportCoords,
  getDefaultViewportConfig,
  calculateCenterTransform,
  type ViewportConfig 
} from "@/utils/coordinateUtils";

const initialAssets: Omit<Asset, 'id' | 'children'>[] = [
  { 
    name: "Project Folder", 
    type: "other", 
    x: 100, 
    y: 100, 
    customFields: [],
    viewportConfig: {
      zoom: 1.2,
      panX: 50,
      panY: 30,
    },
    backgroundConfig: {
      color: '#1a1a2e',
      gridSize: 30,
    },
  },
  { name: "Project Overview.pdf", type: "document", x: 60, y: 80, customFields: [] },
  { name: "Hero Banner.png", type: "image", x: 300, y: 150, customFields: [] },
  { name: "Background Music.mp3", type: "audio", x: 150, y: 250, customFields: [] },
];

export function AssetPort() {
  const [selectedAsset, setSelectedAsset] = useState<string | null>(null);
  const [isDragging, setIsDragging] = useState(false);
  const [dragOffset, setDragOffset] = useState({ x: 0, y: 0 });
  const [currentViewport, setCurrentViewport] = useState<ViewportConfig>(getDefaultViewportConfig());
  const [enteredAssetId, setEnteredAssetId] = useState<string | null>(null);
  const containerRef = useRef<HTMLDivElement>(null);
  const hasInitialized = useRef(false);

  const {
    assets,
    activeAsset,
    deleteAsset,
    updateAssetPosition,
    setActiveAsset,
    getRootAssets,
    searchAssets,
  } = useAssetTree();
  
  const { createAsset: createStoreAsset } = useAssetStore();

  // Initialize with some sample assets on first render
  useEffect(() => {
    if (!hasInitialized.current && Object.keys(assets).length === 0) {
      hasInitialized.current = true;
      const folderId = createStoreAsset(initialAssets[0]); // Create the folder first
      
      // Create child assets and assign them to the folder
      initialAssets.slice(1).forEach(assetData => {
        createStoreAsset(assetData, folderId);
      });
    }
  }, [assets.length, createStoreAsset]);

  const handleAddAsset = useCallback((newAsset: Omit<Asset, "id" | "x" | "y" | "children">) => {
    const containerRect = containerRef.current?.getBoundingClientRect();
    const randomX = 50 + Math.random() * ((containerRect?.width || 400) - 250);
    const randomY = 80 + Math.random() * ((containerRect?.height || 300) - 150);
    
    createStoreAsset({
      ...newAsset,
      x: randomX,
      y: randomY,
    }, enteredAssetId || undefined); // Use enteredAssetId as parent if inside an asset
  }, [createStoreAsset, enteredAssetId]);

  const handleDeleteAsset = useCallback((id: string) => {
    deleteAsset(id);
  }, [deleteAsset]);

  const handleAssetDoubleClick = useCallback((asset: Asset) => {
    // Enter the asset by setting it as the active asset and updating viewport
    setActiveAsset(asset.id);
    setEnteredAssetId(asset.id);
    
    // Calculate viewport to center the asset
    if (containerRef.current) {
      const rect = containerRef.current.getBoundingClientRect();
      const centerTransform = calculateCenterTransform(asset, rect.width, rect.height);
      
      // Use asset's custom viewport config if available, otherwise use calculated center
      const newViewport = asset.viewportConfig || centerTransform;
      setCurrentViewport(newViewport);
    }
  }, [setActiveAsset]);

  const handleExitAsset = useCallback(() => {
    setEnteredAssetId(null);
    setActiveAsset(null);
    setCurrentViewport(getDefaultViewportConfig());
  }, [setActiveAsset]);

  const handleMouseDown = useCallback((e: React.MouseEvent, asset: Asset) => {
    e.preventDefault();
    setSelectedAsset(asset.id);
    setActiveAsset(asset.id);
    setIsDragging(true);
    
    const rect = (e.target as HTMLElement).closest('.asset-item')?.getBoundingClientRect();
    if (rect) {
      setDragOffset({
        x: e.clientX - rect.left,
        y: e.clientY - rect.top,
      });
    }
  }, [setActiveAsset]);

  const handleMouseMove = useCallback((e: MouseEvent) => {
    if (!isDragging || !selectedAsset || !containerRef.current) return;
    
    const containerRect = containerRef.current.getBoundingClientRect();
    const screenX = e.clientX - containerRect.left - dragOffset.x;
    const screenY = e.clientY - containerRect.top - dragOffset.y;
    
    // Convert screen coordinates to viewport coordinates
    const viewportCoords = screenToViewportCoords(
      { x: screenX, y: screenY },
      currentViewport
    );
    
    // Keep within bounds (in viewport space)
    const boundedX = Math.max(0, Math.min(viewportCoords.x, containerRect.width - 200));
    const boundedY = Math.max(0, Math.min(viewportCoords.y, containerRect.height - 50));
    
    // Convert to global coordinates if we're inside an asset
    let finalX = boundedX;
    let finalY = boundedY;
    
    if (enteredAssetId && assets[enteredAssetId]) {
      const parentAsset = assets[enteredAssetId];
      // Convert from local (viewport) to global coordinates
      const globalCoords = localToGlobalCoords(
        { x: boundedX, y: boundedY },
        parentAsset,
        currentViewport
      );
      finalX = globalCoords.x;
      finalY = globalCoords.y;
    }
    
    // Update asset position in store
    updateAssetPosition(selectedAsset, finalX, finalY);
  }, [isDragging, selectedAsset, dragOffset, updateAssetPosition, enteredAssetId, assets, currentViewport]);

  const handleMouseUp = useCallback(() => {
    setIsDragging(false);
   }, []);

  const handleContainerClick = useCallback((e: React.MouseEvent) => {
    if (e.target === e.currentTarget) {
      setSelectedAsset(null);
      // Exit asset if we're inside one
      if (enteredAssetId) {
        handleExitAsset();
      } else {
        setActiveAsset(null);
      }
    }
  }, [enteredAssetId, handleExitAsset, setActiveAsset]);

  useEffect(() => {
    if (isDragging) {
      window.addEventListener("mousemove", handleMouseMove);
      window.addEventListener("mouseup", handleMouseUp);
      return () => {
        window.removeEventListener("mousemove", handleMouseMove);
        window.removeEventListener("mouseup", handleMouseUp);
      };
    }
  }, [isDragging, handleMouseMove, handleMouseUp]);

  // Get assets to display based on current context
  const displayAssets = enteredAssetId 
    ? assets[enteredAssetId]?.children.map(childId => assets[childId]).filter(Boolean) || []
    : getRootAssets();

  // Get current background config
  const currentBackgroundConfig = enteredAssetId && assets[enteredAssetId]
    ? assets[enteredAssetId].backgroundConfig
    : undefined;

   return (
    <div className="glass-strong cosmic-glow rounded-2xl w-full h-full flex flex-col mx-auto my-auto">
       {/* Header */}
      <div className="flex items-center justify-between p-4 border-b border-glass-border/20">
         <div className="flex items-center gap-2">
           {enteredAssetId && (
             <button
               onClick={handleExitAsset}
               className="p-1 hover:bg-muted rounded transition-colors"
               title="Exit asset"
             >
               <ArrowLeft className="w-4 h-4 text-muted-foreground" />
             </button>
           )}
           <Sparkles className="w-5 h-5 text-accent text-glow-accent" />
           <h2 className="text-lg font-semibold text-foreground text-glow">
             {enteredAssetId && assets[enteredAssetId] 
               ? `Inside: ${assets[enteredAssetId].name}` 
               : 'Asset Port'
             }
           </h2>
          <span className="text-xs text-muted-foreground ml-2">
            ({displayAssets.length} {enteredAssetId ? 'child' : 'root'} assets)
          </span>
         </div>
         <AddAssetDialog onAddAsset={handleAddAsset} />
       </div>

      {/* Canvas Area */}
      <div
        ref={containerRef}
        onClick={handleContainerClick}
        className="flex-1 relative overflow-hidden cursor-crosshair"
        style={{
          backgroundImage: currentBackgroundConfig?.image 
            ? `url(${currentBackgroundConfig.image})`
            : `
              radial-gradient(circle at 1px 1px, hsl(var(--glass-border) / 0.15) 1px, transparent 0)
            `,
          backgroundSize: currentBackgroundConfig?.image 
            ? 'cover' 
            : `${currentBackgroundConfig?.gridSize || 40}px ${currentBackgroundConfig?.gridSize || 40}px`,
          backgroundColor: currentBackgroundConfig?.color || 'transparent',
        }}
      >
        {/* Viewport transform container */}
        <div
          style={{
            transform: `scale(${currentViewport.zoom}) translate(${currentViewport.panX}px, ${currentViewport.panY}px)`,
            transformOrigin: '0 0',
            width: '100%',
            height: '100%',
          }}
        >
         {displayAssets.length === 0 ? (
          <div className="flex flex-col items-center justify-center text-muted-foreground" style={{ height: '100%' }}>
             <Sparkles className="w-8 h-8 mb-2 opacity-50" />
             <p className="text-sm">
               {enteredAssetId ? 'No child assets' : 'No assets yet'}
             </p>
             <p className="text-xs opacity-70">
               {enteredAssetId 
                 ? 'Double-click parent assets to add children' 
                 : 'Add your first asset to get started'
               }
             </p>
           </div>
         ) : (
          displayAssets.map((asset) => {
            // Convert asset position to local coordinates if we're inside a parent
            let displayAsset = { ...asset };
            
            if (enteredAssetId && assets[enteredAssetId]) {
              const parentAsset = assets[enteredAssetId];
              // Convert from global to local coordinates
              const localCoords = globalToLocalCoords(
                { x: asset.x, y: asset.y },
                parentAsset,
                currentViewport
              );
              displayAsset = {
                ...asset,
                x: localCoords.x,
                y: localCoords.y,
              };
            }
            
            return (
              <AssetItem
                key={asset.id}
                asset={displayAsset}
                onDelete={handleDeleteAsset}
                onMouseDown={handleMouseDown}
                onDoubleClick={handleAssetDoubleClick}
                isSelected={selectedAsset === asset.id}
              />
            );
          })
         )}
        </div>
       </div>

      {/* Footer */}
      <div className="p-3 border-t border-glass-border/20">
        <p className="text-xs text-muted-foreground text-center opacity-70">
          {enteredAssetId 
            ? 'Double-click assets to enter • Click outside to exit • Drag to move'
            : 'Drag assets anywhere • Double-click to enter • Click canvas to deselect'
          }
        </p>
       </div>
     </div>
   );
 }
