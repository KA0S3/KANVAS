 import { X, FileText, Image, Film, Music, Code, File, Move } from "lucide-react";
import type { CustomField } from "@/types/extendedAsset";

export interface Asset {
  id: string;
  name: string;
  type: "image" | "document" | "video" | "audio" | "code" | "other";
  x: number;
  y: number;
  parentId?: string; // undefined for root-level assets
  children: string[]; // array of child asset IDs
  description?: string;
  customFields: CustomField[];
  thumbnail?: string; // Base64 encoded image
  background?: string; // Base64 encoded image
  tags?: string[];
  viewportConfig?: {
    zoom: number;
    panX: number;
    panY: number;
  };
  backgroundConfig?: {
    color?: string;
    image?: string;
    gridSize?: number;
  };
}

interface AssetItemProps {
  asset: Asset;
  onDelete: (id: string) => void;
  onMouseDown: (e: React.MouseEvent, asset: Asset) => void;
  onDoubleClick?: (asset: Asset) => void;
  isSelected: boolean;
}

const iconMap = {
  image: Image,
  document: FileText,
  video: Film,
  audio: Music,
  code: Code,
  other: File,
};

const colorMap = {
  image: "text-primary",
  document: "text-accent",
  video: "text-secondary",
  audio: "text-glow-primary",
  code: "text-primary",
  other: "text-muted-foreground",
};

 export function AssetItem({ asset, onDelete, onMouseDown, onDoubleClick, isSelected }: AssetItemProps) {
  const Icon = iconMap[asset.type];
  const colorClass = colorMap[asset.type];

  return (
    <div
      onMouseDown={(e) => onMouseDown(e, asset)}
      onDoubleClick={() => onDoubleClick?.(asset)}
      style={{
        position: "absolute",
        left: asset.x,
        top: asset.y,
        transform: isSelected ? "scale(1.05)" : "scale(1)",
      }}
      className={`asset-item group flex items-center gap-3 select-none cursor-grab active:cursor-grabbing transition-transform duration-100 ${
        isSelected ? "cosmic-glow z-20 border-primary/60" : "z-10"
      }`}
    >
      <Move className="w-4 h-4 text-muted-foreground opacity-50 group-hover:opacity-100 transition-opacity" />
      <Icon className={`w-5 h-5 ${colorClass}`} />
      <span className="flex-1 text-sm text-foreground truncate">{asset.name}</span>
      <button
        onClick={(e) => {
          e.stopPropagation();
          onDelete(asset.id);
        }}
        className="opacity-0 group-hover:opacity-100 transition-opacity p-1 hover:bg-destructive/20 rounded"
      >
        <X className="w-4 h-4 text-destructive" />
      </button>
    </div>
  );
}