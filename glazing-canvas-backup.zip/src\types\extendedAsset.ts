import type { Asset } from '@/components/AssetItem';

export interface CustomField {
  id: string;
  name: string;
  value: string;
  showOnCanvas: boolean; // Toggle for CanvasItem display
}

export interface ExtendedAsset extends Asset {
  description?: string;
  customFields: CustomField[];
  thumbnail?: string; // Base64 encoded image
  background?: string; // Base64 encoded image
  tags?: string[];
}

export interface GeneratorData {
  type: 'character' | 'city' | 'item' | 'location';
  data: Record<string, any>;
}

export interface AssetEditFormData {
  name: string;
  description?: string;
  customFields: CustomField[];
  thumbnail?: string;
  background?: string;
  tags?: string[];
}
