import { create } from 'zustand';
import type { Asset } from '@/components/AssetItem';
import type { CustomField } from '@/types/extendedAsset';

interface AssetStore {
  // Registry for O(1) lookups
  assets: Record<string, Asset>;
  
  // Active asset state
  currentActiveId: string | null;
  
  // Actions
  createAsset: (assetData: Omit<Asset, 'id' | 'children'>, parentId?: string) => string;
  reparentAsset: (assetId: string, newParentId?: string) => void;
  deleteAsset: (assetId: string) => void;
  updateAssetPosition: (assetId: string, x: number, y: number) => void;
  updateAsset: (assetId: string, updates: Partial<Omit<Asset, 'id' | 'children' | 'parentId'>>) => void;
  setActiveAsset: (assetId: string | null) => void;
  getActiveAsset: () => Asset | null;
  getRootAssets: () => Asset[];
  getAssetChildren: (parentId: string) => Asset[];
  getAssetTree: (rootId?: string) => Asset[];
}

export const useAssetStore = create<AssetStore>((set, get) => ({
  // Initial state
  assets: {},
  currentActiveId: null,

  // Create a new asset
  createAsset: (assetData: Omit<Asset, 'id' | 'children'>, parentId?: string) => {
    const id = crypto.randomUUID();
    const newAsset: Asset = {
      ...assetData,
      id,
      children: [],
      parentId,
      customFields: assetData.customFields || [],
      tags: assetData.tags || [],
      viewportConfig: assetData.viewportConfig || {
        zoom: 1,
        panX: 0,
        panY: 0,
      },
      backgroundConfig: assetData.backgroundConfig || {
        gridSize: 40,
      },
    };

    set((state) => {
      const newAssets = { ...state.assets };
      
      // Add the new asset to registry
      newAssets[id] = newAsset;
      
      // If it has a parent, add this asset to parent's children array
      if (parentId && newAssets[parentId]) {
        newAssets[parentId] = {
          ...newAssets[parentId],
          children: [...newAssets[parentId].children, id],
        };
      }
      
      return { assets: newAssets };
    });

    return id;
  },

  // Reparent an asset (move from one parent to another)
  reparentAsset: (assetId: string, newParentId?: string) => {
    set((state) => {
      const newAssets = { ...state.assets };
      const asset = newAssets[assetId];
      
      if (!asset) return state;

      const oldParentId = asset.parentId;

      // Remove from old parent's children array
      if (oldParentId && newAssets[oldParentId]) {
        newAssets[oldParentId] = {
          ...newAssets[oldParentId],
          children: newAssets[oldParentId].children.filter(id => id !== assetId),
        };
      }

      // Add to new parent's children array
      if (newParentId && newAssets[newParentId]) {
        newAssets[newParentId] = {
          ...newAssets[newParentId],
          children: [...newAssets[newParentId].children, assetId],
        };
      }

      // Update the asset's parent reference
      newAssets[assetId] = {
        ...asset,
        parentId: newParentId,
      };

      return { assets: newAssets };
    });
  },

  // Update asset position
  updateAssetPosition: (assetId: string, x: number, y: number) => {
    set((state) => {
      const asset = state.assets[assetId];
      if (!asset) return state;

      return {
        assets: {
          ...state.assets,
          [assetId]: {
            ...asset,
            x,
            y,
          },
        },
      };
    });
  },

  // Update asset properties
  updateAsset: (assetId: string, updates: Partial<Omit<Asset, 'id' | 'children' | 'parentId'>>) => {
    set((state) => {
      const asset = state.assets[assetId];
      if (!asset) return state;

      return {
        assets: {
          ...state.assets,
          [assetId]: {
            ...asset,
            ...updates,
          },
        },
      };
    });
  },

  // Delete an asset and all its descendants recursively
  deleteAsset: (assetId: string) => {
    set((state) => {
      const newAssets = { ...state.assets };
      const asset = newAssets[assetId];
      
      if (!asset) return state;

      // Recursive function to collect all descendant IDs
      const collectDescendants = (id: string): string[] => {
        const currentAsset = newAssets[id];
        if (!currentAsset || currentAsset.children.length === 0) return [];
        
        let descendants: string[] = [];
        for (const childId of currentAsset.children) {
          descendants.push(childId);
          descendants = descendants.concat(collectDescendants(childId));
        }
        return descendants;
      };

      // Collect all IDs to delete (asset + all descendants)
      const idsToDelete = [assetId, ...collectDescendants(assetId)];

      // Remove from parent's children array if it has a parent
      if (asset.parentId && newAssets[asset.parentId]) {
        newAssets[asset.parentId] = {
          ...newAssets[asset.parentId],
          children: newAssets[asset.parentId].children.filter(id => !idsToDelete.includes(id)),
        };
      }

      // Delete all assets from registry
      idsToDelete.forEach(id => {
        delete newAssets[id];
      });

      // Clear active asset if it was deleted
      const newActiveId = state.currentActiveId && idsToDelete.includes(state.currentActiveId) 
        ? null 
        : state.currentActiveId;

      return { 
        assets: newAssets,
        currentActiveId: newActiveId,
      };
    });
  },

  // Set the active asset
  setActiveAsset: (assetId: string | null) => {
    set({ currentActiveId: assetId });
  },

  // Get the active asset object
  getActiveAsset: () => {
    const state = get();
    return state.currentActiveId ? state.assets[state.currentActiveId] || null : null;
  },

  // Get all root-level assets (no parent)
  getRootAssets: () => {
    const state = get();
    return Object.values(state.assets).filter(asset => !asset.parentId);
  },

  // Get direct children of a specific asset
  getAssetChildren: (parentId: string) => {
    const state = get();
    const parent = state.assets[parentId];
    if (!parent) return [];
    
    return parent.children
      .map(childId => state.assets[childId])
      .filter(Boolean);
  },

  // Get entire tree starting from root or specific asset
  getAssetTree: (rootId?: string) => {
    const state = get();
    const result: Asset[] = [];
    
    const traverse = (assetId: string) => {
      const asset = state.assets[assetId];
      if (!asset) return;
      
      result.push(asset);
      asset.children.forEach(traverse);
    };

    if (rootId) {
      traverse(rootId);
    } else {
      // Start from all root assets
      state.getRootAssets().forEach(asset => traverse(asset.id));
    }
    
    return result;
  },
}));
