import { useState } from "react";
import {
  Folder,
  Plus,
  Search,
  Settings,
  Tag,
  Users,
  Castle,
  Sparkles,
  Swords,
  SlidersHorizontal,
  ChevronDown,
  Layers,
} from "lucide-react";
import cosmicBackground from "@/assets/cosmic-background.png";
import { AssetPort } from "@/components/AssetPort";
import { AssetTreeContainer } from "@/components/AssetTreeContainer";
import { useAssetStore } from "@/stores/assetStore";

const Index = () => {
  const [sidebarOpen, setSidebarOpen] = useState(true);
  const { currentActiveId } = useAssetStore();

  return (
    <div className="relative min-h-screen w-full overflow-hidden">
      {/* Cosmic Background */}
      <div 
        className="absolute inset-0 bg-center bg-no-repeat"
        style={{ 
          backgroundImage: `url(${cosmicBackground})`,
          backgroundSize: "85%",
        }}
      />
      
      {/* Subtle overlay for better glass contrast */}
      <div className="absolute inset-0 bg-background/20" />
      
      {/* Full-screen Asset Port - positioned above the book area */}
      <div className="relative z-10 flex flex-col h-screen p-4 pt-2">
        <div className="flex-1 w-full mx-auto pb-4" style={{ height: "calc(100vh - 120px)" }}>
          <div className="min-h-[420px] h-full max-w-7xl mx-auto relative">
            <div className="absolute right-4 top-4 z-20">
              <button
                type="button"
                className="glass cosmic-glow rounded-full border border-glass-border/40 px-3 py-1.5 text-xs uppercase tracking-[0.2em] text-foreground/80 hover:text-foreground"
                onClick={() => setSidebarOpen((prev) => !prev)}
              >
                {sidebarOpen ? "Hide Shelf" : "Show Shelf"}
              </button>
            </div>
            <AssetPort />
          </div>
        </div>
      </div>

      <aside className={`fantasy-overlay ${sidebarOpen ? "is-open" : ""}`} aria-hidden={!sidebarOpen}>
        <div className="fantasy-sidebar">
          <div className="fantasy-sidebar-content">
              <div className="flex items-center justify-between mb-5">
                <div className="flex items-center gap-3 text-muted-foreground">
                  <button
                    type="button"
                    className="fantasy-icon-btn"
                    aria-label="Settings"
                  >
                    <Settings className="h-4 w-4" />
                  </button>
                  <button
                    type="button"
                    className="fantasy-icon-btn"
                    aria-label="Tags"
                  >
                    <Tag className="h-4 w-4" />
                    <span className="text-[11px] uppercase tracking-[0.16em]">Tags</span>
                  </button>
                </div>
                <button
                  type="button"
                  className="text-[11px] uppercase tracking-[0.2em] text-muted-foreground hover:text-foreground"
                  onClick={() => setSidebarOpen(false)}
                >
                  Collapse
                </button>
              </div>

              <div className="flex gap-2 mb-5 flex-wrap">
                <button type="button" className="fantasy-tab">
                  <Users className="h-4 w-4" />
                  <span>Characters</span>
                </button>
                <button type="button" className="fantasy-tab">
                  <Castle className="h-4 w-4" />
                  <span>Cities</span>
                </button>
                <button type="button" className="fantasy-tab">
                  <Sparkles className="h-4 w-4" />
                  <span>Gods</span>
                </button>
                <button type="button" className="fantasy-tab">
                  <Swords className="h-4 w-4" />
                  <span>Battles</span>
                </button>
              </div>

              <div className="fantasy-divider mb-4" />

              {/* Asset Tree */}
              <div className="flex-1 min-h-0">
                <AssetTreeContainer 
                  selectedAssetId={currentActiveId}
                  className="h-full"
                />
              </div>

              <div className="fantasy-footer">
                <Layers className="h-4 w-4" />
                <span>Background</span>
              </div>
          </div>
        </div>
      </aside>
    </div>
  );
};

export default Index;
