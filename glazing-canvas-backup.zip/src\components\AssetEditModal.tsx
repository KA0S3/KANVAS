import { useForm, useFieldArray } from 'react-hook-form';
import { zodResolver } from '@hookform/resolvers/zod';
import * as z from 'zod';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter } from '@/components/ui/dialog';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Textarea } from '@/components/ui/textarea';
import { Label } from '@/components/ui/label';
import { Switch } from '@/components/ui/switch';
import { Badge } from '@/components/ui/badge';
import { Plus, X, Upload, Image as ImageIcon } from 'lucide-react';
import { convertImageToBase64, createImagePreview, validateImageFile } from '@/utils/fileReader';
import type { ExtendedAsset, CustomField } from '@/types/extendedAsset';

const customFieldSchema = z.object({
  id: z.string(),
  name: z.string().min(1, 'Field name is required'),
  value: z.string(),
  showOnCanvas: z.boolean(),
});

const assetEditSchema = z.object({
  name: z.string().min(1, 'Asset name is required'),
  description: z.string().optional(),
  customFields: z.array(customFieldSchema),
  thumbnail: z.string().optional(),
  background: z.string().optional(),
  tags: z.array(z.string()).optional(),
});

type AssetEditFormData = z.infer<typeof assetEditSchema>;

interface AssetEditModalProps {
  asset: ExtendedAsset | null;
  isOpen: boolean;
  onClose: () => void;
  onSave: (asset: ExtendedAsset) => void;
}

export function AssetEditModal({ asset, isOpen, onClose, onSave }: AssetEditModalProps) {
  const {
    register,
    control,
    handleSubmit,
    watch,
    setValue,
    formState: { errors },
  } = useForm<AssetEditFormData>({
    resolver: zodResolver(assetEditSchema),
    defaultValues: {
      name: asset?.name || '',
      description: asset?.description || '',
      customFields: asset?.customFields || [],
      thumbnail: asset?.thumbnail || '',
      background: asset?.background || '',
      tags: asset?.tags || [],
    },
  });

  const { fields, append, remove } = useFieldArray({
    control,
    name: 'customFields',
  });

  const watchedThumbnail = watch('thumbnail');
  const watchedBackground = watch('background');

  const handleImageUpload = async (event: React.ChangeEvent<HTMLInputElement>, field: 'thumbnail' | 'background') => {
    const file = event.target.files?.[0];
    if (!file) return;

    if (!validateImageFile(file)) {
      alert('Please upload a valid image file (JPEG, PNG, GIF, WebP) under 5MB');
      return;
    }

    try {
      const base64 = await convertImageToBase64(file);
      setValue(field, base64);
    } catch (error) {
      console.error('Failed to convert image:', error);
      alert('Failed to process image');
    }
  };

  const addCustomField = () => {
    append({
      id: crypto.randomUUID(),
      name: '',
      value: '',
      showOnCanvas: false,
    });
  };

  const onSubmit = (data: AssetEditFormData) => {
    if (!asset) return;

    const updatedAsset: ExtendedAsset = {
      ...asset,
      name: data.name,
      description: data.description,
      customFields: data.customFields,
      thumbnail: data.thumbnail,
      background: data.background,
      tags: data.tags,
    };

    onSave(updatedAsset);
    onClose();
  };

  return (
    <Dialog open={isOpen} onOpenChange={onClose}>
      <DialogContent className="max-w-2xl max-h-[90vh] overflow-y-auto">
        <DialogHeader>
          <DialogTitle>Edit Asset</DialogTitle>
        </DialogHeader>

        <form onSubmit={handleSubmit(onSubmit)} className="space-y-6">
          {/* Basic Information */}
          <div className="space-y-4">
            <div>
              <Label htmlFor="name">Name</Label>
              <Input
                id="name"
                {...register('name')}
                className="mt-1"
              />
              {errors.name && (
                <p className="text-sm text-destructive mt-1">{errors.name.message}</p>
              )}
            </div>

            <div>
              <Label htmlFor="description">Description</Label>
              <Textarea
                id="description"
                {...register('description')}
                className="mt-1"
                rows={3}
              />
            </div>
          </div>

          {/* Image Uploads */}
          <div className="grid grid-cols-2 gap-4">
            <div className="space-y-2">
              <Label>Thumbnail</Label>
              <div className="space-y-2">
                {watchedThumbnail && (
                  <div className="relative">
                    <img
                      src={createImagePreview(watchedThumbnail)}
                      alt="Thumbnail preview"
                      className="w-full h-32 object-cover rounded-md border"
                    />
                    <Button
                      type="button"
                      variant="destructive"
                      size="sm"
                      className="absolute top-2 right-2"
                      onClick={() => setValue('thumbnail', '')}
                    >
                      <X className="w-4 h-4" />
                    </Button>
                  </div>
                )}
                <div className="relative">
                  <Input
                    type="file"
                    accept="image/*"
                    onChange={(e) => handleImageUpload(e, 'thumbnail')}
                    className="sr-only"
                    id="thumbnail-upload"
                  />
                  <Button
                    type="button"
                    variant="outline"
                    className="w-full"
                    onClick={() => document.getElementById('thumbnail-upload')?.click()}
                  >
                    <Upload className="w-4 h-4 mr-2" />
                    Upload Thumbnail
                  </Button>
                </div>
              </div>
            </div>

            <div className="space-y-2">
              <Label>Background</Label>
              <div className="space-y-2">
                {watchedBackground && (
                  <div className="relative">
                    <img
                      src={createImagePreview(watchedBackground)}
                      alt="Background preview"
                      className="w-full h-32 object-cover rounded-md border"
                    />
                    <Button
                      type="button"
                      variant="destructive"
                      size="sm"
                      className="absolute top-2 right-2"
                      onClick={() => setValue('background', '')}
                    >
                      <X className="w-4 h-4" />
                    </Button>
                  </div>
                )}
                <div className="relative">
                  <Input
                    type="file"
                    accept="image/*"
                    onChange={(e) => handleImageUpload(e, 'background')}
                    className="sr-only"
                    id="background-upload"
                  />
                  <Button
                    type="button"
                    variant="outline"
                    className="w-full"
                    onClick={() => document.getElementById('background-upload')?.click()}
                  >
                    <Upload className="w-4 h-4 mr-2" />
                    Upload Background
                  </Button>
                </div>
              </div>
            </div>
          </div>

          {/* Custom Fields */}
          <div className="space-y-4">
            <div className="flex items-center justify-between">
              <Label>Custom Fields</Label>
              <Button type="button" variant="outline" size="sm" onClick={addCustomField}>
                <Plus className="w-4 h-4 mr-2" />
                Add Field
              </Button>
            </div>

            <div className="space-y-3">
              {fields.map((field, index) => (
                <div key={field.id} className="flex items-center gap-2 p-3 border rounded-md">
                  <div className="flex-1 space-y-2">
                    <Input
                      placeholder="Field name"
                      {...register(`customFields.${index}.name`)}
                    />
                    <Input
                      placeholder="Field value"
                      {...register(`customFields.${index}.value`)}
                    />
                  </div>
                  <div className="flex items-center gap-2">
                    <div className="flex flex-col items-center">
                      <Label htmlFor={`show-on-canvas-${index}`} className="text-xs mb-1">
                        Canvas
                      </Label>
                      <Switch
                        id={`show-on-canvas-${index}`}
                        {...register(`customFields.${index}.showOnCanvas`)}
                      />
                    </div>
                    <Button
                      type="button"
                      variant="ghost"
                      size="sm"
                      onClick={() => remove(index)}
                    >
                      <X className="w-4 h-4" />
                    </Button>
                  </div>
                </div>
              ))}
            </div>
          </div>

          <DialogFooter>
            <Button type="button" variant="outline" onClick={onClose}>
              Cancel
            </Button>
            <Button type="submit">
              Save Changes
            </Button>
          </DialogFooter>
        </form>
      </DialogContent>
    </Dialog>
  );
}
